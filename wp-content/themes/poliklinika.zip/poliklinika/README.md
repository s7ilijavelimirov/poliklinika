<<<<<<< HEAD
## Webpack 5 WordPress Theme Boilerplate

Provides a boilerplate WordPress theme that features a webpack 5 build for CSS/SASS and JavaScript. The webpack configuration is defined in the [webpack.config.js](./webpack.config.js), and the compiled assets are included in the WordPress theme via code in the [functions.php](./functions.php).

## Development

- `npm run all` - Pokrece sve komande iz webpack.